#ifndef CFUNCTIONH_H_
#define  CFUNCTIONH_H_

void InputCrossM(CrossM *M);
Status transpose(CrossM *M);
Status Display(CrossM *M);


#endif